O arquivo de dependencias e o crontab se encontra junto aos arquivos !
